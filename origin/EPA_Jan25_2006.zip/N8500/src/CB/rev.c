CODE_DATA const BYTE Relase[] =  "Copyright by Good Will / Instek \n"
                                 "MACHIME NO. GW MAIN CONTORLLER 8500\n"
                                 "SOFTWARE DEVELOP: Kun-Yi Chen \n"
                                 "EMAIL:kunichen@ms8.url.com.tw \n"
                                 "VESION: 3.0 \n"
                                 "Data: 2003/10/12\n";    
